# MilPay (MVP)

A local-first, military-focused paycheck and budget calculator with retirement projections.

## Quick start
```bash
npm install
npm run dev
```

Deploy free on Vercel.
