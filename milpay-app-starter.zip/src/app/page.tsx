export default function Home() {
  return (
    <main>
      <h1>MilPay (MVP)</h1>
      <p>Enter LES values, see accurate mid-month & EOM nets, build a paycheck-based budget, and project BRS/High-3 + TSP.</p>
      <p>This is a minimal starter. All calculations run locally in your browser.</p>
    </main>
  );
}
